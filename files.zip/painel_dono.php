<?php
session_start();
include "config.php";
include "helpers.php";

verificar_login('dono');

// Fallback PHP para atualização de status (o caminho principal é via AJAX)
if (isset($_POST['atualizar_status'])) {
    verificar_csrf();
    $id_pedido = (int)$_POST['id_pedido'];
    $status    = $_POST['status'] ?? '';
    $validos   = ['pendente', 'preparando', 'pronto', 'entregue', 'cancelado'];
    if (in_array($status, $validos, true)) {
        $stmt = $conn->prepare("UPDATE pedidos SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $status, $id_pedido);
        $stmt->execute();
        $stmt->close();
    }
    redirecionar('painel_dono.php', 'Status atualizado!');
}

// ── STATS ────────────────────────────────────────────────────
$stats = $conn->query(
    "SELECT COUNT(DISTINCT id) as total_pedidos,
            SUM(total) as faturamento_total,
            SUM(CASE WHEN status='pendente' THEN 1 ELSE 0 END) as pedidos_pendentes
     FROM pedidos"
)->fetch_assoc();

$total_produtos = $conn->query(
    "SELECT COUNT(*) as t FROM produtos WHERE disponivel=1"
)->fetch_assoc()['t'];

$total_clientes = $conn->query(
    "SELECT COUNT(*) as t FROM usuarios WHERE tipo='cliente'"
)->fetch_assoc()['t'];

// ── PEDIDOS (página inicial — o AJAX atualiza depois) ────────
$pagina  = max(1, (int)($_GET['pagina'] ?? 1));
$por_pag = 20;
$offset  = ($pagina - 1) * $por_pag;

$total_pedidos_db = (int)$conn->query("SELECT COUNT(*) as t FROM pedidos")->fetch_assoc()['t'];
$total_paginas    = (int)ceil($total_pedidos_db / $por_pag);

$stmt = $conn->prepare(
    "SELECT p.*, u.nome as cliente_nome, u.telefone, u.endereco
     FROM pedidos p
     JOIN usuarios u ON p.id_cliente = u.id
     ORDER BY p.criado_em DESC
     LIMIT ? OFFSET ?"
);
$stmt->bind_param("ii", $por_pag, $offset);
$stmt->execute();
$pedidos = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

foreach ($pedidos as &$pedido) {
    $stmt_i = $conn->prepare(
        "SELECT pi.*, pr.nome as produto_nome
         FROM pedido_itens pi
         JOIN produtos pr ON pi.id_produto = pr.id
         WHERE pi.id_pedido = ?"
    );
    $stmt_i->bind_param("i", $pedido['id']);
    $stmt_i->execute();
    $itens = $stmt_i->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt_i->close();
    $pedido['itens']       = $itens;
    $pedido['total_itens'] = count($itens);
}
unset($pedido);

$status_cores = ['pendente'=>'#f59e0b','preparando'=>'#3b82f6','pronto'=>'#10b981','entregue'=>'#6b7280','cancelado'=>'#ef4444'];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Admin - FarmaVida</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        .paginacao { display:flex; gap:6px; justify-content:center; margin-top:20px; flex-wrap:wrap; }
        .paginacao a, .paginacao span {
            padding:7px 14px; border-radius:var(--radius-full); font-size:13px; font-weight:600;
            border:1px solid var(--border); text-decoration:none; color:var(--text2);
        }
        .paginacao a:hover { border-color:var(--primary); color:var(--primary); }
        .paginacao .atual  { background:var(--primary); border-color:var(--primary); color:white; }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-container">
            <div class="logo" style="cursor:default;">
                <div class="logo-icon"><i class="fas fa-prescription-bottle-medical"></i></div>
                Farma<span>Vida</span>
                <span style="font-size:13px;color:var(--text2);font-weight:500;margin-left:4px;">Admin</span>
                <button onclick="atualizarPedidos(); atualizarStats();" class="btn btn-secondary"
                        style="margin-left:12px;padding:7px 14px;font-size:12px;">
                    <i class="fas fa-sync-alt"></i> Atualizar
                </button>
                <span class="auto-update-badge" style="margin-left:8px;"><i class="fas fa-clock"></i> 30s</span>
            </div>
            <div class="nav-buttons">
                <a href="relatorios.php"          class="btn btn-info"     ><i class="fas fa-chart-line"></i> Relatórios</a>
                <a href="nfe.php"                 class="btn btn-secondary"><i class="fas fa-file-invoice"></i> NF-e</a>
                <a href="erp.php"                 class="btn btn-secondary"><i class="fas fa-plug"></i> ERP</a>
                <a href="gerenciar_produtos.php"  class="btn btn-success"  ><i class="fas fa-boxes"></i> Produtos</a>
                <a href="estoque.php"             class="btn btn-primary"  id="btn-estoque" style="position:relative;">
                    <i class="fas fa-boxes-stacked"></i> Estoque
                    <span class="badge-num" id="estoque-alert-badge" style="display:none;background:#f59e0b;"></span>
                </a>
                <a href="limpar_pedidos_antigos.php?executar=1" class="btn btn-warning"
                   onclick="return confirm('Limpar pedidos finalizados?')">
                    <i class="fas fa-trash-alt"></i>
                </a>
                <a href="index.php"   class="btn btn-secondary"><i class="fas fa-store"></i></a>
                <a href="logout.php"  class="btn btn-danger"   ><i class="fas fa-sign-out-alt"></i></a>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="card">
            <h1><i class="fas fa-tachometer-alt" style="color:var(--primary);"></i> Painel Administrativo</h1>
            <p style="color:var(--text2);">Bem-vindo, <?= htmlspecialchars($_SESSION['usuario']) ?>!</p>
        </div>

        <div id="estoque-alert-banner" style="display:none;"></div>

        <?php if (isset($_SESSION['sucesso'])): ?>
            <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?= $_SESSION['sucesso'] ?></div>
            <?php unset($_SESSION['sucesso']); ?>
        <?php endif; ?>

        <!-- STATS -->
        <div class="stats-grid">
            <div class="stat-card">
                <i class="fas fa-receipt"></i>
                <div class="stat-numero" id="stat-total-pedidos"><?= $stats['total_pedidos'] ?></div>
                <div class="stat-label">Total de Pedidos</div>
            </div>
            <div class="stat-card">
                <i class="fas fa-sack-dollar"></i>
                <div class="stat-numero" id="stat-faturamento" style="font-size:20px;"><?= formatar_preco($stats['faturamento_total'] ?? 0) ?></div>
                <div class="stat-label">Faturamento Total</div>
            </div>
            <div class="stat-card">
                <i class="fas fa-clock"></i>
                <div class="stat-numero" id="stat-pendentes"><?= $stats['pedidos_pendentes'] ?></div>
                <div class="stat-label">Pedidos Pendentes</div>
            </div>
            <div class="stat-card">
                <i class="fas fa-users"></i>
                <div class="stat-numero" id="stat-clientes"><?= $total_clientes ?></div>
                <div class="stat-label">Clientes</div>
            </div>
            <div class="stat-card">
                <i class="fas fa-pills"></i>
                <div class="stat-numero" id="stat-produtos"><?= $total_produtos ?></div>
                <div class="stat-label">Produtos Disponíveis</div>
            </div>
        </div>

        <!-- PEDIDOS -->
        <div class="card">
            <h2><i class="fas fa-clipboard-list"></i> Pedidos</h2>

            <div id="pedidos-container">
                <?php if (empty($pedidos)): ?>
                    <div class="empty"><i class="fas fa-receipt"></i><h2>Nenhum pedido ainda</h2></div>
                <?php else: ?>
                    <?php foreach ($pedidos as $pedido): ?>
                        <div class="pedido <?= $pedido['conta_solicitada'] == 1 ? 'pedido-conta-solicitada' : '' ?>"
                             id="pedido-<?= $pedido['id'] ?>">
                            <div class="pedido-header">
                                <div style="flex:1;">
                                    <?php if ($pedido['conta_solicitada'] == 1): ?>
                                        <div style="background:var(--warning);color:#fff;padding:7px 14px;border-radius:var(--radius-full);margin-bottom:10px;font-weight:700;display:inline-flex;align-items:center;gap:8px;font-size:13px;">
                                            <i class="fas fa-cash-register"></i> CLIENTE QUER PAGAR!
                                        </div>
                                    <?php endif; ?>
                                    <div class="pedido-numero">Pedido #<?= $pedido['id'] ?></div>
                                    <?php $is_delivery = strpos($pedido['observacoes'] ?? '', 'DELIVERY') !== false; ?>
                                    <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;flex-wrap:wrap;">
                                        <span style="display:inline-flex;align-items:center;gap:6px;padding:3px 12px;border-radius:20px;font-size:11px;font-weight:700;<?= $is_delivery ? 'background:rgba(77,156,255,.12);color:var(--secondary);' : 'background:rgba(0,229,160,.1);color:var(--primary);' ?>">
                                            <i class="fas fa-<?= $is_delivery ? 'motorcycle' : 'store-alt' ?>"></i>
                                            <?= $is_delivery ? 'Delivery' : 'Retirada no Local' ?>
                                        </span>
                                        <?php if (($pedido['forma_pagamento'] ?? '') === 'app'): ?>
                                            <?php
                                            $pg_cores = ['aprovado'=>['#059669','circle-check','Pago'],'em_analise'=>['#d97706','clock','Em análise'],'recusado'=>['#dc2626','circle-xmark','Recusado'],'cancelado'=>['#6b7280','ban','Cancelado'],'pendente'=>['#d97706','clock','Aguard. pag.']];
                                            $pg = $pg_cores[$pedido['pagamento_status'] ?? 'pendente'] ?? $pg_cores['pendente'];
                                            ?>
                                            <span style="display:inline-flex;align-items:center;gap:5px;padding:3px 12px;border-radius:20px;font-size:11px;font-weight:700;background:<?= $pg[0] ?>1a;color:<?= $pg[0] ?>;">
                                                <i class="fas fa-<?= $pg[1] ?>"></i> <?= $pg[2] ?> · MP
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="pedido-info">
                                        <strong><i class="fas fa-user"></i></strong> <?= htmlspecialchars($pedido['cliente_nome']) ?><br>
                                        <?php if ($pedido['telefone']): ?><strong><i class="fas fa-phone"></i></strong> <?= htmlspecialchars($pedido['telefone']) ?><br><?php endif; ?>
                                        <?php if ($pedido['endereco']): ?><strong><i class="fas fa-map-marker-alt"></i></strong> <?= htmlspecialchars($pedido['endereco']) ?><br><?php endif; ?>
                                        <strong><i class="fas fa-calendar-alt"></i></strong> <?= date('d/m/Y H:i', strtotime($pedido['criado_em'])) ?>
                                        <?php if ($pedido['observacoes']): ?><br><strong><i class="fas fa-comment-medical"></i></strong> <?= htmlspecialchars($pedido['observacoes']) ?><?php endif; ?>
                                    </div>

                                    <div class="pedido-itens">
                                        <strong><i class="fas fa-pills"></i> Itens do Pedido:</strong>
                                        <ul class="lista-itens">
                                            <?php foreach ($pedido['itens'] as $item): ?>
                                                <li>
                                                    <span class="item-qty"><?= $item['quantidade'] ?>x</span>
                                                    <span class="item-name"><?= htmlspecialchars($item['produto_nome']) ?></span>
                                                    <span class="item-price"><?= formatar_preco($item['preco_unitario'] * $item['quantidade']) ?></span>
                                                </li>
                                            <?php endforeach; ?>
                                        </ul>
                                    </div>

                                    <div class="pedido-total"><?= formatar_preco($pedido['total']) ?></div>
                                </div>

                                <div class="status-form">
                                    <select id="status-<?= $pedido['id'] ?>"
                                            onchange="atualizarStatus(<?= $pedido['id'] ?>, this.value)">
                                        <option value="pendente"   <?= $pedido['status']=='pendente'  ?'selected':'' ?>>Aguardando</option>
                                        <option value="preparando" <?= $pedido['status']=='preparando'?'selected':'' ?>>Separando</option>
                                        <option value="pronto"     <?= $pedido['status']=='pronto'    ?'selected':'' ?>><?= $is_delivery ? 'Saiu p/ entrega' : 'Pronto p/ Retirada' ?></option>
                                        <option value="entregue"   <?= $pedido['status']=='entregue'  ?'selected':'' ?>><?= $is_delivery ? 'Entregue' : 'Retirado' ?></option>
                                        <option value="cancelado"  <?= $pedido['status']=='cancelado' ?'selected':'' ?>>Cancelado</option>
                                    </select>
                                    <a href="imprimir_pedido.php?id=<?= $pedido['id'] ?>" target="_blank"
                                       class="btn btn-primary" style="padding:10px 18px;text-decoration:none;">
                                        <i class="fas fa-print"></i> Nota
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>

                    <!-- PAGINAÇÃO -->
                    <?php if ($total_paginas > 1): ?>
                    <div class="paginacao">
                        <?php if ($pagina > 1): ?>
                            <a href="?pagina=<?= $pagina - 1 ?>">&#8592; Anterior</a>
                        <?php endif; ?>
                        <?php for ($i = max(1, $pagina - 2); $i <= min($total_paginas, $pagina + 2); $i++): ?>
                            <?php if ($i === $pagina): ?>
                                <span class="atual"><?= $i ?></span>
                            <?php else: ?>
                                <a href="?pagina=<?= $i ?>"><?= $i ?></a>
                            <?php endif; ?>
                        <?php endfor; ?>
                        <?php if ($pagina < $total_paginas): ?>
                            <a href="?pagina=<?= $pagina + 1 ?>">Próxima &#8594;</a>
                        <?php endif; ?>
                        <span style="color:var(--text2);padding:7px 0;">
                            Página <?= $pagina ?> de <?= $total_paginas ?>
                        </span>
                    </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        function mostrarToast(msg, tipo='success') {
            const t = document.createElement('div');
            t.className = `toast ${tipo==='error'?'error':''}`;
            t.innerHTML = `<i class="fas fa-${tipo==='success'?'check':'exclamation'}-circle"></i> ${msg}`;
            document.body.appendChild(t);
            setTimeout(()=>{ t.style.opacity='0'; setTimeout(()=>t.remove(),300); }, 3000);
        }

        async function atualizarStatus(idPedido, status) {
            try {
                const fd = new FormData();
                fd.append('action','atualizar_status');
                fd.append('id_pedido', idPedido);
                fd.append('status', status);
                const data = await (await fetch('ajax_handler.php', {method:'POST', body:fd})).json();
                if (data.sucesso) { mostrarToast('Status atualizado!'); atualizarStats(); }
                else mostrarToast(data.erro || 'Erro', 'error');
            } catch(e) { mostrarToast('Erro de conexão','error'); }
        }

        function formatarPreco(v) { return 'R$ '+parseFloat(v).toFixed(2).replace('.',',').replace(/\B(?=(\d{3})+(?!\d))/g,'.'); }
        function formatarData(d) { const dt=new Date(d); return dt.toLocaleDateString('pt-BR')+' '+dt.toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'}); }

        async function atualizarStats() {
            try {
                const data = await (await fetch('ajax_handler.php?action=buscar_stats_dono')).json();
                if (data.stats) {
                    document.getElementById('stat-total-pedidos').textContent = data.stats.total_pedidos||0;
                    document.getElementById('stat-faturamento').textContent   = formatarPreco(data.stats.faturamento_total||0);
                    document.getElementById('stat-pendentes').textContent     = data.stats.pedidos_pendentes||0;
                    document.getElementById('stat-clientes').textContent      = data.total_clientes||0;
                    document.getElementById('stat-produtos').textContent      = data.total_produtos||0;
                }
            } catch(e) {}
        }

        let pedidosAtuais = new Set([<?= implode(',', array_column($pedidos, 'id')) ?>]);

        async function atualizarPedidos() {
            try {
                const data = await (await fetch('ajax_handler.php?action=buscar_pedidos_dono')).json();
                if (!data.pedidos || !data.pedidos.length) return;
                const container = document.getElementById('pedidos-container');
                let html = ''; let novosPedidos = false;

                data.pedidos.forEach(pedido => {
                    const isNovo     = !pedidosAtuais.has(pedido.id);
                    const isDelivery = pedido.observacoes && pedido.observacoes.includes('DELIVERY');
                    if (isNovo) { novosPedidos = true; pedidosAtuais.add(pedido.id); }

                    let itensHtml = '';
                    (pedido.itens||[]).forEach(item => {
                        itensHtml += `<li><span class="item-qty">${item.quantidade}x</span><span class="item-name">${item.produto_nome}</span><span class="item-price">${formatarPreco(item.preco_unitario*item.quantidade)}</span></li>`;
                    });

                    html += `<div class="pedido ${isNovo?'pedido-novo':''} ${pedido.conta_solicitada==1?'pedido-conta-solicitada':''}" id="pedido-${pedido.id}">
                        <div class="pedido-header">
                            <div style="flex:1;">
                                ${pedido.conta_solicitada==1?`<div style="background:var(--warning);color:#fff;padding:7px 14px;border-radius:var(--radius-full);margin-bottom:10px;font-weight:700;display:inline-flex;align-items:center;gap:8px;font-size:13px;"><i class="fas fa-cash-register"></i> CLIENTE QUER PAGAR!</div>`:''}
                                <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;">
                                    <div class="pedido-numero" style="margin-bottom:0;">Pedido #${pedido.id}</div>
                                    <span style="padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700;${isDelivery?'background:rgba(77,156,255,.12);color:var(--secondary);':'background:rgba(0,229,160,.1);color:var(--primary);'}">
                                        ${isDelivery?'<i class="fas fa-motorcycle"></i> Delivery':'<i class="fas fa-store-alt"></i> Retirada'}
                                    </span>
                                </div>
                                <div class="pedido-info">
                                    <strong><i class="fas fa-user"></i></strong> ${pedido.cliente_nome}<br>
                                    ${pedido.telefone?`<strong><i class="fas fa-phone"></i></strong> ${pedido.telefone}<br>`:''}
                                    <strong><i class="fas fa-calendar-alt"></i></strong> ${formatarData(pedido.criado_em)}
                                    ${pedido.observacoes?`<br><strong><i class="fas fa-comment-medical"></i></strong> ${pedido.observacoes}`:''}
                                </div>
                                <div class="pedido-itens"><strong><i class="fas fa-pills"></i> Itens:</strong><ul class="lista-itens">${itensHtml}</ul></div>
                                <div class="pedido-total">${formatarPreco(pedido.total)}</div>
                            </div>
                            <div class="status-form">
                                <select id="status-${pedido.id}" onchange="atualizarStatus(${pedido.id}, this.value)">
                                    <option value="pendente"   ${pedido.status==='pendente'  ?'selected':''}>Aguardando</option>
                                    <option value="preparando" ${pedido.status==='preparando'?'selected':''}>Separando</option>
                                    <option value="pronto"     ${pedido.status==='pronto'    ?'selected':''}>${isDelivery ? 'Saiu p/ entrega' : 'Pronto p/ Retirada'}</option>
                                    <option value="entregue"   ${pedido.status==='entregue'  ?'selected':''}>${isDelivery ? 'Entregue' : 'Retirado'}</option>
                                    <option value="cancelado"  ${pedido.status==='cancelado' ?'selected':''}>Cancelado</option>
                                </select>
                                <a href="imprimir_pedido.php?id=${pedido.id}" target="_blank"
                                   class="btn btn-primary" style="padding:10px 18px;text-decoration:none;">
                                    <i class="fas fa-print"></i> Nota
                                </a>
                            </div>
                        </div>
                    </div>`;
                });

                container.innerHTML = html;
                if (novosPedidos) mostrarToast('Novo pedido recebido!');
            } catch(e) { console.error(e); }
        }

        async function verificarEstoque() {
            try {
                const data = await (await fetch('ajax_handler.php?action=alertas_estoque')).json();
                const banner = document.getElementById('estoque-alert-banner');
                const badge  = document.getElementById('estoque-alert-badge');
                const total  = (data.zerados || 0) + (data.baixos || 0);

                if (total > 0) {
                    badge.textContent   = total;
                    badge.style.display = 'flex';
                    let itensHtml = '';
                    (data.criticos || []).forEach(p => {
                        const cor = p.estoque_atual === 0 ? '#dc2626' : '#d97706';
                        itensHtml += `<span style="background:${cor}22;color:${cor};padding:2px 10px;border-radius:20px;font-size:12px;font-weight:700;white-space:nowrap;">${p.nome}: ${p.estoque_atual} un</span>`;
                    });
                    banner.style.display = 'block';
                    banner.innerHTML = `
                        <div style="background:linear-gradient(135deg,#fef3c7,#fde68a);border:1.5px solid #f59e0b;border-radius:var(--radius-md);padding:16px 20px;margin-bottom:24px;display:flex;align-items:flex-start;gap:14px;">
                            <i class="fas fa-triangle-exclamation" style="font-size:22px;color:#d97706;flex-shrink:0;margin-top:2px;"></i>
                            <div style="flex:1;">
                                <strong style="color:#92400e;display:block;margin-bottom:8px;">⚠️ Estoque crítico: ${data.zerados} produto(s) zerado(s), ${data.baixos} abaixo do mínimo</strong>
                                <div style="display:flex;gap:8px;flex-wrap:wrap;">${itensHtml}</div>
                            </div>
                            <a href="estoque.php" class="btn btn-warning" style="padding:8px 16px;font-size:13px;flex-shrink:0;">
                                <i class="fas fa-boxes-stacked"></i> Gerenciar Estoque
                            </a>
                        </div>`;
                } else {
                    badge.style.display  = 'none';
                    banner.style.display = 'none';
                }
            } catch(e) {}
        }

        setInterval(() => { atualizarPedidos(); atualizarStats(); verificarEstoque(); }, 30000);
        setTimeout(() => { atualizarStats(); verificarEstoque(); }, 1000);
    </script>
</body>
</html>
